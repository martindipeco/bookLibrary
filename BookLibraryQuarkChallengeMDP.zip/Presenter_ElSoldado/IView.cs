﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presenter_ElSoldado
{
    public interface IView
    {
        void Show_text(string texto);
    }
}
