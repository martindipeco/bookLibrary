﻿using System;
using Presenter_ElSoldado;

namespace View_ElSoldado
{
    class Program
    {
        static void Main(string[] args)
        {
            View menu = new();
        }
    }
}
